/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Derived Class - Friend Contact.
*/
public class FriendContact : Contact
//Represents a friend contact with inherited contact properties
{
    public string Nickname { get; private set; }
    //Property definition

    public FriendContact(int id, string firstName, string lastName, string phoneNumber, string nickname)
        : base(id, firstName, lastName, phoneNumber)
    {
        Nickname = nickname;
    }

    public FriendContact(int id, string firstName, string lastName)
        : base(id, firstName, lastName)
    {
        Nickname = "Unknown";        
    }

    public override void Display()
    {
        Console.WriteLine($"[Friend] {FirstName} {LastName} | Nickname: {Nickname} | Phone: {PhoneNumber}");
        //Display output to user
    }
    public override string GetSummary() => $"{Nickname} ({FirstName} {LastName})";
}