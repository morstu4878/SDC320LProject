/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Derived Class - Family Contact.
*/
public class FamilyContact : Contact
//Represents a family contact who inherited contact properties
{
    public string Relationship { get; private set; }
    //Property definition

    public FamilyContact(int id, string firstName, string lastName, string phoneNumber, string relationship)
        : base(id, firstName, lastName, phoneNumber)
    {
        Relationship = relationship;
    }

    public override void Display()
    {
        Console.WriteLine($"[Family] {FirstName} {LastName} | Relationship: {Relationship} | Phone: {PhoneNumber}");
        //Display output to user
    }
    public override string GetSummary() => $"{FirstName} {LastName} ({Relationship})";
}