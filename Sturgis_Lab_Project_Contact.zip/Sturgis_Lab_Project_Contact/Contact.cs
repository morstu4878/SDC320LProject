/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Abstract Base Class
*/
public abstract class Contact : IContactActions
//Base class for all contact types (Business, Family, Friend)
{
    public int ID { get; private set; }
    //Property definition
    public string FirstName { get; private set; }
    //Property definition
    public string LastName { get; private set; }
    //Property definition
    public string PhoneNumber { get; private set; }
    //Property definition

    public Contact(int id, string firstName, string lastName, string phoneNumber = "N/A")
    {
        ID = id;
        FirstName = firstName;
        LastName = lastName;
        PhoneNumber = phoneNumber;
    }

    public abstract void Display(); //Polymorphic Behavior
    public abstract string GetSummary();
}