/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Main application class.
*/
using System.Data.SQLite;

public class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to your Personal Contact Organizer!");

        const string dbName = "MorganSturgis.db";
        SQLiteConnection conn = SQLiteDatabase.Connect(dbName);

        if (conn != null)
        {
            ContactDb.CreateTable(conn);

            while (true)
            {
                Console.WriteLine("\nChoose contact type to create:");
                Console.WriteLine("1. Business Contact");
                Console.WriteLine("2. Family Contact");
                Console.WriteLine("3. Friend Contact");
                Console.WriteLine("4. Exit");
                Console.Write("Enter choice (1-4): ");
                string? choice = Console.ReadLine();
                while (choice is not ("1" or "2" or "3" or "4"))
                {
                    Console.Write("Invalid choice. Enter a number between 1 and 4: ");
                    choice = Console.ReadLine();
                }

                if (choice == "4") break;

                Console.Write("Enter Contact ID: ");
                string? idInput = Console.ReadLine();
                int id = int.TryParse(idInput, out int parsedId) ? parsedId : 0;

                Console.Write("Enter First Name: ");
                string firstName = Console.ReadLine() ?? "Unknown";

                Console.Write("Enter Last Name: ");
                string lastName = Console.ReadLine() ?? "Unknown";

                Console.Write("Enter Phone Number: ");
                string phone = Console.ReadLine() ?? "N/A";

                switch (choice)
                //Create contact based on selected type
                {
                    case "1":
                    //Business contact selected
                        Console.Write("Enter Company Name: ");
                        string company = Console.ReadLine() ?? "Unknown";
                        ContactDb.AddContact(conn, new BusinessContact(id, firstName, lastName, phone, company));
                        break;
                    case "2":
                    //Family contact selected
                        Console.Write("Enter Relationship: ");
                        string relationship = Console.ReadLine() ?? "Unknown";
                        ContactDb.AddContact(conn, new FamilyContact(id, firstName, lastName, phone, relationship));
                        break;
                    case "3":
                    //Friend contact selected
                        Console.Write("Enter Nickname: ");
                        string nickname = Console.ReadLine() ?? "Unknown";
                        ContactDb.AddContact(conn, new FriendContact(id, firstName, lastName, phone, nickname));
                        break;
                    default:
                    //Unknown option (fallback)
                        Console.WriteLine("Invalid choice.");
                        break;
                }

                Console.WriteLine("\nAll Contacts in the Database:");
                var allContacts = ContactDb.GetAllContacts(conn);
                foreach (var contact in allContacts)
                {
                    contact.Display();
                }
            }
        }
    }
}

