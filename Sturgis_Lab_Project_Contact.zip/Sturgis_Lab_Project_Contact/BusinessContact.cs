/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Derived Class - Business Contact.
*/
public class BusinessContact : Contact
//Represents a business contact with inherited contact properties
{
    public string Company { get; private set; }
    //Property definition

    public BusinessContact(int id, string firstName, string lastName, string phoneNumber, string company)
        : base(id, firstName, lastName, phoneNumber)
    {
        Company = company;
    }

    public override void Display()
    {
        Console.WriteLine($"[Business] {FirstName} {LastName} | Company: {Company} | Phone: {PhoneNumber}");
        //Display output to user
    }
    public override string GetSummary() => $"{FirstName} {LastName} @ {Company}";
}