/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Interface: Defines Common Behavior
*/
public interface IContactActions
//Interface to define actions applicable to contact types
{
    void Display(); // Will be implemented polymorphically
    string GetSummary();
}