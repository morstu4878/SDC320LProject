# Project Name: Rolodex Contact Manager

## Project Description
Rolodex Contact Manager is a console-based C# application that allows users to manage their personal contacts effectively. It supports different types of contacts such as Business, Family, and Friends. The application demonstrates object-oriented programming concepts and integrates SQLite for persistent data storage.

## Project Tasks
- **Task 1: Define class hierarchy**
  - Create an abstract base class `Contact`
  - Implement derived classes: `BusinessContact`, `FamilyContact`, `FriendContact`
  - Create interface `IContactActions` for standard operations
- **Task 2: Implement contact management features**
  - Add functionality to create, update, delete, and list contacts
  - Include filtering by last name initial
- **Task 3: Setup database integration**
  - Connect to SQLite using `System.Data.SQLite`
  - Implement table creation and CRUD operations in `ContactDb.cs`
- **Task 4: Build the user interface**
  - Create console menu for interaction
  - Accept input for contact details and operation selection
- **Task 5: Document and test**
  - Add inline comments and class-level documentation
  - Perform manual testing to validate contact operations

## Project Skills Learned
- Object-Oriented Programming in C#
- Use of Abstract Classes, Inheritance, Interfaces, and Composition
- Working with SQLite databases
- Console application design and user interaction
- Error handling and input validation
- File organization and project structure in Visual Studio Code

## Language Used
- **C#**: Primary programming language
- **SQLite**: Database for data persistence

## Development Process Used
- **Incremental Development**: Building one feature at a time and validating through testing.
- **Code Documentation**: Clear inline comments and structured class headers for better maintainability.

## Notes
- Ensure the SQLite library (`System.Data.SQLite`) is available in your environment.
- Run the application using `dotnet run` from the project root directory.
- The database file `MorganSturgis.db` will be created automatically in the project folder.

## Video Demo
[Watch the Video Demonstration](https://youtu.be/tQYsFZcakqE)  

## Link to Project Repository
[GitHub Repository](https://github.com/morstu4878/SDC320LProject)  