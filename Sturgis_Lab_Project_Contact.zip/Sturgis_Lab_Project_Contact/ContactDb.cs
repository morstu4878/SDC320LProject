/**********************************************************************
* Name: Morgan Sturgis
* Date: 6/15/2025
* Assignment: SDC320L Project - Rolodex/Contacts App
*
* Database logic for contact storage.
*/
using System.Data.SQLite;

public class ContactDb
//Base class for all contact types (Business, Family, Friend)
{
    public static void CreateTable(SQLiteConnection conn)
    {
        string sql =
            "CREATE TABLE IF NOT EXISTS Contacts (\n"
            + "     ID integer PRIMARY KEY\n"
            + "     ,FirstName varchar(20)\n"
            + "     ,LastName varchar(40)\n"
            + "     ,PhoneNumber varchar(20)\n"
            + "     ,Relationship varchar(50)\n"
            + "     ,Company varchar(50)\n"
            + "     ,Nickname varchar(50));";

        SQLiteCommand cmd = conn.CreateCommand();
        //Prepare SQLite command
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }

    public static void AddContact(SQLiteConnection conn, Contact c)
    {
        string sql = "";

        if (c is FamilyContact fc)
        {
            sql = string.Format(
                "INSERT INTO Contacts (ID, FirstName, LastName, PhoneNumber, Relationship) " +
                "VALUES ({0}, '{1}', '{2}', '{3}', '{4}')",
                fc.ID, fc.FirstName, fc.LastName, fc.PhoneNumber, fc.Relationship);
        }
        else if (c is BusinessContact bc)
        {
            sql = string.Format(
                "INSERT INTO Contacts (ID, FirstName, LastName, PhoneNumber, Company) " +
                "VALUES ({0}, '{1}', '{2}', '{3}', '{4}')",
                bc.ID, bc.FirstName, bc.LastName, bc.PhoneNumber, bc.Company);
        }
        else if (c is FriendContact fr)
        {
            sql = string.Format(
                "INSERT INTO Contacts (ID, FirstName, LastName, PhoneNumber, Nickname) " +
                "VALUES ({0}, '{1}', '{2}', '{3}', '{4}')",
                fr.ID, fr.FirstName, fr.LastName, fr.PhoneNumber, fr.Nickname);
        }
        else
        {
            sql = string.Format(
                "INSERT INTO Contacts (ID, FirstName, LastName, PhoneNumber) " +
                "VALUES ({0}, '{1}', '{2}', '{3}')",
                c.ID, c.FirstName, c.LastName, c.PhoneNumber);
        }

        SQLiteCommand cmd = conn.CreateCommand();
        //Prepare SQLite command
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }
    public static List<Contact> GetAllContacts(SQLiteConnection conn)
    {
        List<Contact> contacts = new List<Contact>();
        string sql = "SELECT * FROM Contacts";

        SQLiteCommand cmd = conn.CreateCommand();
        //Prepare SQLite command
        cmd.CommandText = sql;
        SQLiteDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            int id = Convert.ToInt32(reader["ID"]);
            string firstName = reader["FirstName"].ToString() ?? "Unknown";
            string lastName = reader["LastName"].ToString() ?? "Unknown";
            string phoneNumber = reader["PhoneNumber"].ToString() ?? "N/A";
            string relationship = reader["Relationship"].ToString() ?? "";
            string company = reader["Company"].ToString() ?? "";
            string nickname = reader["Nickname"].ToString() ?? "";

            if (!string.IsNullOrWhiteSpace(company))
            {
                contacts.Add(new BusinessContact(id, firstName, lastName, phoneNumber, company));
            }
            else if (!string.IsNullOrWhiteSpace(relationship))
            {
                contacts.Add(new FamilyContact(id, firstName, lastName, phoneNumber, relationship));
            }
            else if (!string.IsNullOrWhiteSpace(nickname))
            {
                contacts.Add(new FriendContact(id, firstName, lastName, phoneNumber, nickname));
            }
            else
            {
                contacts.Add(new FamilyContact(id, firstName, lastName, phoneNumber, "Unknown")); // fallback
            }
        }

        return contacts;
    }
}